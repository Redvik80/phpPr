<html>

<head>
    <title>1.5 канал</title>
    <meta charset="utf-8">

    <link rel="stylesheet" type="text/css" href="/node_modules/primeicons/primeicons.css" />

    <link href="/node_modules/quill/dist/quill.snow.css" rel="stylesheet">
    <script src="/node_modules/quill/dist/quill.min.js" defer></script>

    <link rel="stylesheet" href="/dist/home-advertising.css">
    <script src="/dist/home-advertising.js" defer></script>
</head>

<body>
    <?include "../../components/navigation/navigation.php"?>
    <?include "../../components/advertisingCrud/advertisingCrud.php"?>
</body>

</html>