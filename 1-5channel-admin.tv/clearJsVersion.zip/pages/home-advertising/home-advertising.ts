import "./home-advertising.scss";
import "../../components/advertisingCrud/advertisingCrud.ts";