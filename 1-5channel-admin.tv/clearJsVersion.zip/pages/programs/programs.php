<html>

<head>
    <title>1.5 канал</title>
    <meta charset="utf-8">

    <link rel="stylesheet" type="text/css" href="/node_modules/primeicons/primeicons.css" />

    <link rel="stylesheet" href="/dist/programs.css">
    <script src="/dist/programs.js" defer></script>
</head>

<body>
    <?include "../../components/navigation/navigation.php"?>
    <?include "../../components/programsCrud/programsCrud.php"?>
</body>

</html>