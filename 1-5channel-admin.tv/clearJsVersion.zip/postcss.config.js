module.exports = {
    plugins: {
        'autoprefixer': {}
    }
}